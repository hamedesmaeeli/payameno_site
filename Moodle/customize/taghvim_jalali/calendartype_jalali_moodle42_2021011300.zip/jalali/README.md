The Jalali calendar (also known as the Modern Iranian calendar or the Solar hijri calendar) is a solar calendar which is the official calendar in Iran and Afghanistan.

The calendar type system was introduced in 2.6, so this will not work in any Moodle versions earlier than this.

To install this calendar type do either of the folllowing steps.

========================== Git (recommended) ==========================

Once you have git installed, simply visit the calendar/type folder in your Moodle directory and clone https://github.com/rezaies/moodle-calendartype_jalali.git, remember to rename the folder to jalali if you do not specify this in the clone command.

Eg. Linux command line would be as follow -

git clone https://github.com/rezaies/moodle-calendartype_jalali.git jalali

Use git pull to update this repository periodically to ensure you have the latest version.

============================= Download ================================

Download and extract the zip, rename the folder to jalali and place this folder in the calendar/type folder in your Moodle directory.
